/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"


#include "xbasic_types.h"
#include "xparameters.h"

#define PICCOLO_80_SPEED_FLAG_ENCRYPT (1<<16)
#define PICCOLO_80_RESSOURCES_FLAG_ENCRYPT (1<<16)
#define PICCOLO_80_RESSOURCES_FLAG_DATA_READY (1<<17)
#define PICCOLO_80_RESSOURCES_FLAG_CIPHER_READY (1<<0)


Xuint64 piccolo_80_speed(Xuint32 *hardware, Xuint32 dataMSB,Xuint32 dataLSB, Xuint32 Flag_keyUpper,Xuint32 keyMiddle, Xuint32 keyLower)
{
	//data in
	hardware[0]= dataMSB;
	hardware[1]= dataLSB;

	//Key + FLAG
	hardware[4] = Flag_keyUpper;
	hardware[5] = keyMiddle;
	hardware[6] = keyLower;


	return *(((Xuint64 *)hardware)+1); // return the value of the encrypted data
}

void piccolo_80_ressources_reset(Xuint32 *hardware)
{
	// set the data ready to hight -> put the block on reset mode and is waiting for data
	hardware[4] |= PICCOLO_80_RESSOURCES_FLAG_DATA_READY;
}

Xuint64 piccolo_80_ressources(Xuint32 *hardware, Xuint32 dataMSB,Xuint32 dataLSB, Xuint32 Flag_keyUpper,Xuint32 keyMiddle, Xuint32 keyLower)
{

	Xuint64 retour;

	//Key + FLAG (data ready on High -> inputing data)
	hardware[4] = Flag_keyUpper | PICCOLO_80_RESSOURCES_FLAG_DATA_READY;
	hardware[5] = keyMiddle;
	hardware[6] = keyLower;

	//data in
	hardware[0]= dataMSB;
	hardware[1]= dataLSB;

	//data ready on low -> start encryption
	hardware[4] &= ~PICCOLO_80_RESSOURCES_FLAG_DATA_READY;

	while ((hardware[7] & PICCOLO_80_RESSOURCES_FLAG_CIPHER_READY) != 0)
	{
		// wait for the encryption (25 clock cycle)
	}

	retour = *(((Xuint64 *)hardware)+1); //save the encrypted data
	// set the data ready to hight -> put the block on reset mode and is waiting for data
	piccolo_80_ressources_reset(hardware);

	return retour; //return the encrypted data (as a value)
}

int main()
{
	init_platform();

	Xuint64 val;

	xil_printf("Piccolo_80 Test\n\r");


	xil_printf("Piccolo_80_speed Test\n\r");
	xil_printf("Decryption of 0x8D2BFF9935F84056 with the key 0x00112233445566778899\n\r");
	val=piccolo_80_speed((Xuint32 *)XPAR_PICCOLO_80_SPEED_0_S00_AXI_BASEADDR,0x8D2BFF99,0x35F84056,
			(~PICCOLO_80_SPEED_FLAG_ENCRYPT) & 0x0011,0x22334455,0x66778899);
	xil_printf("Decrypted data is: 0x%08x%08x \n\r", val.Upper,val.Lower);

	xil_printf("Encryption of 0x0123456789abcdef with the key 0x00112233445566778899\n\r");
	val=piccolo_80_speed((Xuint32 *)XPAR_PICCOLO_80_SPEED_0_S00_AXI_BASEADDR,0x01234567,0x89abcdef,
			PICCOLO_80_SPEED_FLAG_ENCRYPT | 0x0011,0x22334455,0x66778899);
	xil_printf("Encrypted data is: 0x%08x%08x \n\r", val.Upper,val.Lower);

	xil_printf("Piccolo_80_ressources Test\n\r");
	piccolo_80_ressources_reset((Xuint32 *)XPAR_PICCOLO_80_RESSOURCES_0_S00_AXI_BASEADDR);
	xil_printf("Decryption of 0x8D2BFF9935F84056 with the key 0x00112233445566778899\n\r");
	val=piccolo_80_ressources((Xuint32 *)XPAR_PICCOLO_80_RESSOURCES_0_S00_AXI_BASEADDR,0x8D2BFF99,0x35F84056,
			(~PICCOLO_80_RESSOURCES_FLAG_ENCRYPT) & 0x0011,0x22334455,0x66778899);
	xil_printf("Decrypted data is: 0x%08x%08x \n\r", val.Upper,val.Lower);

	xil_printf("Encryption of 0x0123456789abcdef with the key 0x00112233445566778899\n\r");
	val=piccolo_80_ressources((Xuint32 *)XPAR_PICCOLO_80_RESSOURCES_0_S00_AXI_BASEADDR,0x01234567,0x89abcdef,
			PICCOLO_80_RESSOURCES_FLAG_ENCRYPT | 0x0011,0x22334455,0x66778899);
	xil_printf("Encrypted data is: 0x%08x%08x \n\r", val.Upper,val.Lower);

	xil_printf("End of test\n\n\r");


    return 0;
}

